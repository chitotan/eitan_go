// word...回答 mearning...問題
var words = [
// 2.科学と人間
{ word: 'ユーザーの回答', meaning: '出題される問題' },
{ word: 'apple', meaning: 'りんご' },
{ word: 'banana', meaning: 'バナナ' },

    // 他の単語を追加
  ];

  // タイトルを設定　＊必須
  var title = "タイトル";

  // この問題の詳細設定(任意)
  var testconfig = [
    { ScriptVersion : '4.1'}, //変更禁止
    { Version : '1'},
    { 製作者: 'User'},
    { 制作日: '20230621'},
  ];